# 📅 학년별 당번 배정 달력

이 앱은 Streamlit으로 만든 학년별 당번 배정 달력입니다.

## 실행 방법 (로컬)
```bash
pip install -r requirements.txt
streamlit run app.py
```

## 설정 방법
`config.toml` 파일에서 학년별 인원, 이름, 달력 옵션을 수정하세요.
