import streamlit as st
import pandas as pd
import calendar
import random
import toml
from datetime import datetime

# TOML 설정 불러오기
config = toml.load("config.toml")

YEAR = config["calendar"]["year"]
MONTH = config["calendar"]["month"]
EXCLUDE_WEEKENDS = config["calendar"]["exclude_weekends"]

grade1_names = config["grade1"]["names"]
grade2_names = config["grade2"]["names"]

# 달력 만들기
cal = calendar.Calendar()
days = [d for d in cal.itermonthdates(YEAR, MONTH) if d.month == MONTH]

if EXCLUDE_WEEKENDS:
    days = [d for d in days if d.weekday() < 5]

# 랜덤 배정
random.shuffle(grade1_names)
random.shuffle(grade2_names)

assignments = []
for i, day in enumerate(days):
    g1 = grade1_names[i % len(grade1_names)]
    g2 = grade2_names[i % len(grade2_names)]
    assignments.append([day.strftime("%Y-%m-%d"), g1, g2])

df = pd.DataFrame(assignments, columns=["날짜", "1학년", "2학년"])

st.title("📅 학년별 당번 배정 달력")
st.dataframe(df)

st.download_button("CSV 다운로드", df.to_csv(index=False), "duty.csv")
